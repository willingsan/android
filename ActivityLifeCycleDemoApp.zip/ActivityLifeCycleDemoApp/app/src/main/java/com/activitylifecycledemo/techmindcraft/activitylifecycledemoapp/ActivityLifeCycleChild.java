package com.activitylifecycledemo.techmindcraft.activitylifecycledemoapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by jnanesh on 1/28/2015.
 */
public class ActivityLifeCycleChild extends Activity{
    Button btnBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_life_cycle_child);
        Toast.makeText(this, "From onCreate()....Child Class", Toast.LENGTH_LONG).show();

        btnBack = (Button) findViewById(R.id.btnBack);
        
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent oldActivity = new Intent(ActivityLifeCycleChild.this, ActivityLifeCycleMain.class);
                startActivity(oldActivity);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "From onStart()....Child Class", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(this, "From onRestart()....Child Class", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "From onResume()....Child Class", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "From onPause()....Child Class", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "From onStop()....Child Class", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "From onDestroy()....Child Class", Toast.LENGTH_LONG).show();
    }
}
